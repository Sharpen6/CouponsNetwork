﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject.ControllersTests
{
    [TestClass]
    public class CouponControllerTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
