﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CouponsOnline.View
{
    public enum UserType
    {
        Customer,
        Owner,
        Admin
    }
}
